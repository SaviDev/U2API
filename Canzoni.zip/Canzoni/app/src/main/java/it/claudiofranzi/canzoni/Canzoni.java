package it.claudiofranzi.canzoni;

public class Canzoni {

    private String collectionName;
    private String trackName;
    private String previewUrl;
    private double collectionPrice;
    private double trackPrice;

    Canzoni(String collectionName, String trackName, String previewUrl, double collectionPrice, double trackPrice) {
        this.collectionName     = collectionName;
        this. trackName         = trackName;
        this. previewUrl        = previewUrl;
        this.collectionPrice     = collectionPrice;
        this.trackPrice         = trackPrice;
    }

    public String getCollectionName() {
        return collectionName;
    }

    public String getTrackName() {
        return trackName;
    }

    public String getPreviewUrl() {
        return previewUrl;
    }

    public double getTrackPrice() {
        return trackPrice;
    }

    public double getCollectionPrice() {
        return collectionPrice;
    }
}
