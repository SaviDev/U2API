package it.claudiofranzi.canzoni;

public class Model {

    public static String getJSON() {
        return "{\n" +
                "  \"resultCount\": 50,\n" +
                "  \"results\": [\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1443155637,\n" +
                "      \"trackId\": 1443155645,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Joshua Tree\",\n" +
                "      \"trackName\": \"With Or Without You\",\n" +
                "      \"collectionCensoredName\": \"The Joshua Tree\",\n" +
                "      \"trackCensoredName\": \"With Or Without You\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/with-or-without-you/1443155637?i=1443155645&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/with-or-without-you/1443155637?i=1443155645&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview128/v4/0a/65/af/0a65affb-8f37-251d-3445-997790f14996/mzaf_5439870584787736169.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1987-03-09T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 11,\n" +
                "      \"trackNumber\": 3,\n" +
                "      \"trackTimeMillis\": 295516,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1443063058,\n" +
                "      \"trackId\": 1443063492,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"Achtung Baby\",\n" +
                "      \"trackName\": \"One\",\n" +
                "      \"collectionCensoredName\": \"Achtung Baby\",\n" +
                "      \"trackCensoredName\": \"One\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/one/1443063058?i=1443063492&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/one/1443063058?i=1443063492&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/f3/d7/91/f3d79154-03ce-f181-910e-fc9106261c1e/mzaf_4108232025432020311.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1988-11-18T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 12,\n" +
                "      \"trackNumber\": 3,\n" +
                "      \"trackTimeMillis\": 276237,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Pop\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1443155637,\n" +
                "      \"trackId\": 1443155644,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Joshua Tree\",\n" +
                "      \"trackName\": \"I Still Haven't Found What I'm Looking For\",\n" +
                "      \"collectionCensoredName\": \"The Joshua Tree\",\n" +
                "      \"trackCensoredName\": \"I Still Haven't Found What I'm Looking For\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/i-still-havent-found-what-im-looking-for/1443155637?i=1443155644&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/i-still-havent-found-what-im-looking-for/1443155637?i=1443155644&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview128/v4/88/cd/81/88cd81b8-13f8-ffc1-3db0-8b839a396cba/mzaf_1160727057373197983.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1987-03-09T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 11,\n" +
                "      \"trackNumber\": 2,\n" +
                "      \"trackTimeMillis\": 277477,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Pop\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1487549700,\n" +
                "      \"trackId\": 1487550058,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"A Very Special Christmas\",\n" +
                "      \"trackName\": \"Christmas (Baby Please Come Home)\",\n" +
                "      \"collectionCensoredName\": \"A Very Special Christmas\",\n" +
                "      \"trackCensoredName\": \"Christmas (Baby Please Come Home)\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/christmas-baby-please-come-home/1487549700?i=1487550058&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/christmas-baby-please-come-home/1487549700?i=1487550058&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview124/v4/c4/1c/f6/c41cf654-ecce-fb54-05fc-9388048395eb/mzaf_12812278535981354319.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/d5/12/ec/d512eca7-26ea-6520-a004-09f5f79e26c7/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/d5/12/ec/d512eca7-26ea-6520-a004-09f5f79e26c7/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/d5/12/ec/d512eca7-26ea-6520-a004-09f5f79e26c7/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 6.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1987-10-12T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 15,\n" +
                "      \"trackNumber\": 9,\n" +
                "      \"trackTimeMillis\": 139760,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Holiday\",\n" +
                "      \"isStreamable\": true,\n" +
                "      \"collectionArtistId\": 36270,\n" +
                "      \"collectionArtistName\": \"Various Artists\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1442801732,\n" +
                "      \"trackId\": 1442802994,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"Rattle and Hum\",\n" +
                "      \"trackName\": \"All I Want Is You\",\n" +
                "      \"collectionCensoredName\": \"Rattle and Hum\",\n" +
                "      \"trackCensoredName\": \"All I Want Is You\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/all-i-want-is-you/1442801732?i=1442802994&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/all-i-want-is-you/1442801732?i=1442802994&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/60/cd/b2/60cdb22d-ad81-51f5-17a7-fc3744c22e9e/mzaf_1832991023123571600.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is2-ssl.mzstatic.com/image/thumb/Music118/v4/b8/77/a5/b877a592-547e-9535-4afb-c1e01cc235d0/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is2-ssl.mzstatic.com/image/thumb/Music118/v4/b8/77/a5/b877a592-547e-9535-4afb-c1e01cc235d0/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is2-ssl.mzstatic.com/image/thumb/Music118/v4/b8/77/a5/b877a592-547e-9535-4afb-c1e01cc235d0/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1988-10-10T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 17,\n" +
                "      \"trackNumber\": 17,\n" +
                "      \"trackTimeMillis\": 390880,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1443155637,\n" +
                "      \"trackId\": 1443155640,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Joshua Tree\",\n" +
                "      \"trackName\": \"Where the Streets Have No Name\",\n" +
                "      \"collectionCensoredName\": \"The Joshua Tree\",\n" +
                "      \"trackCensoredName\": \"Where the Streets Have No Name\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/where-the-streets-have-no-name/1443155637?i=1443155640&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/where-the-streets-have-no-name/1443155637?i=1443155640&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview128/v4/10/03/17/10031799-6667-3df0-489e-1067fd7cab9a/mzaf_3654378921089627418.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/f9/2d/d5/f92dd55b-1f84-cf16-97f8-a08c5f65d594/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1987-03-09T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 11,\n" +
                "      \"trackNumber\": 1,\n" +
                "      \"trackTimeMillis\": 337506,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1442959667,\n" +
                "      \"trackId\": 1442959856,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"No Line on the Horizon\",\n" +
                "      \"trackName\": \"Moment of Surrender\",\n" +
                "      \"collectionCensoredName\": \"No Line on the Horizon\",\n" +
                "      \"trackCensoredName\": \"Moment of Surrender\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/moment-of-surrender/1442959667?i=1442959856&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/moment-of-surrender/1442959667?i=1442959856&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/8e/90/3a/8e903a23-e6ca-ea82-fd25-fc0b0286e77d/mzaf_8081153573056580595.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"2009-02-25T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 12,\n" +
                "      \"trackNumber\": 3,\n" +
                "      \"trackTimeMillis\": 444302,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1442959667,\n" +
                "      \"trackId\": 1442959984,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"No Line on the Horizon\",\n" +
                "      \"trackName\": \"Breathe\",\n" +
                "      \"collectionCensoredName\": \"No Line on the Horizon\",\n" +
                "      \"trackCensoredName\": \"Breathe\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/breathe/1442959667?i=1442959984&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/breathe/1442959667?i=1442959984&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview128/v4/59/da/36/59da364f-f594-c554-32fa-24edc93bd38b/mzaf_8947494213113911916.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"2009-02-25T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 12,\n" +
                "      \"trackNumber\": 10,\n" +
                "      \"trackTimeMillis\": 300311,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1442959667,\n" +
                "      \"trackId\": 1442959848,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"No Line on the Horizon\",\n" +
                "      \"trackName\": \"Magnificent\",\n" +
                "      \"collectionCensoredName\": \"No Line on the Horizon\",\n" +
                "      \"trackCensoredName\": \"Magnificent\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/magnificent/1442959667?i=1442959848&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/magnificent/1442959667?i=1442959848&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/9a/84/d4/9a84d456-2314-568f-1967-3215fcb29505/mzaf_2999894003821200522.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is4-ssl.mzstatic.com/image/thumb/Music118/v4/9e/d6/ab/9ed6abfb-f215-b5e3-e4e4-286bbcc0e0a1/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"2009-02-25T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 12,\n" +
                "      \"trackNumber\": 2,\n" +
                "      \"trackTimeMillis\": 324014,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1440894594,\n" +
                "      \"trackId\": 1440894781,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Best of 1980-1990\",\n" +
                "      \"trackName\": \"I Will Follow\",\n" +
                "      \"collectionCensoredName\": \"The Best of 1980-1990\",\n" +
                "      \"trackCensoredName\": \"I Will Follow\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/i-will-follow/1440894594?i=1440894781&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/i-will-follow/1440894594?i=1440894781&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/6b/2d/ac/6b2daccd-8b35-dc93-5cdd-fa9f92950913/mzaf_8505794078123560171.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1980-10-20T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 15,\n" +
                "      \"trackNumber\": 8,\n" +
                "      \"trackTimeMillis\": 215840,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1440655963,\n" +
                "      \"trackId\": 1440655974,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Best of 1990-2000\",\n" +
                "      \"trackName\": \"Beautiful Day\",\n" +
                "      \"collectionCensoredName\": \"The Best of 1990-2000\",\n" +
                "      \"trackCensoredName\": \"Beautiful Day\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/beautiful-day/1440655963?i=1440655974&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/beautiful-day/1440655963?i=1440655974&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview124/v4/82/23/31/82233104-45ea-ed0d-32d8-ee7bec53c29c/mzaf_5100515010747760035.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music128/v4/53/4b/a8/534ba82b-a447-128b-b89c-33422f55b2f1/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music128/v4/53/4b/a8/534ba82b-a447-128b-b89c-33422f55b2f1/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music128/v4/53/4b/a8/534ba82b-a447-128b-b89c-33422f55b2f1/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"2000-10-01T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 16,\n" +
                "      \"trackNumber\": 3,\n" +
                "      \"trackTimeMillis\": 244867,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1443063058,\n" +
                "      \"trackId\": 1443063243,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"Achtung Baby\",\n" +
                "      \"trackName\": \"Even Better Than the Real Thing\",\n" +
                "      \"collectionCensoredName\": \"Achtung Baby\",\n" +
                "      \"trackCensoredName\": \"Even Better Than the Real Thing\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/even-better-than-the-real-thing/1443063058?i=1443063243&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/even-better-than-the-real-thing/1443063058?i=1443063243&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview128/v4/55/04/9a/55049af2-8ee7-125a-ffdd-1d6e82bce529/mzaf_3666646496882170673.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/84/0e/ce/840ece24-d4bf-12d0-4bbf-3fcda48a7713/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1988-11-18T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 12,\n" +
                "      \"trackNumber\": 2,\n" +
                "      \"trackTimeMillis\": 221172,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Pop\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1444843331,\n" +
                "      \"trackId\": 1444843332,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"Wide Awake In America - EP\",\n" +
                "      \"trackName\": \"Bad\",\n" +
                "      \"collectionCensoredName\": \"Wide Awake In America - EP\",\n" +
                "      \"trackCensoredName\": \"Bad (Live)\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/bad-live/1444843331?i=1444843332&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/bad-live/1444843331?i=1444843332&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/98/2e/ae/982eae64-dcd2-9e7a-a2ed-0d1e3976a5c1/mzaf_5135247214532197371.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/21/90/d4/2190d46a-42a0-a2c7-d727-731e8d732d1b/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/21/90/d4/2190d46a-42a0-a2c7-d727-731e8d732d1b/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is3-ssl.mzstatic.com/image/thumb/Music128/v4/21/90/d4/2190d46a-42a0-a2c7-d727-731e8d732d1b/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 3.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1985-05-01T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 4,\n" +
                "      \"trackNumber\": 1,\n" +
                "      \"trackTimeMillis\": 484640,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1440894594,\n" +
                "      \"trackId\": 1440894778,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Best of 1980-1990\",\n" +
                "      \"trackName\": \"Bad\",\n" +
                "      \"collectionCensoredName\": \"The Best of 1980-1990\",\n" +
                "      \"trackCensoredName\": \"Bad\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/bad/1440894594?i=1440894778&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/bad/1440894594?i=1440894778&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/b9/8f/0b/b98f0bec-5779-f458-40f2-60ae79092af1/mzaf_7529796783877707887.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1984-10-01T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 15,\n" +
                "      \"trackNumber\": 6,\n" +
                "      \"trackTimeMillis\": 349507,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    },\n" +
                "    {\n" +
                "      \"wrapperType\": \"track\",\n" +
                "      \"kind\": \"song\",\n" +
                "      \"artistId\": 78500,\n" +
                "      \"collectionId\": 1440894594,\n" +
                "      \"trackId\": 1440894914,\n" +
                "      \"artistName\": \"U2\",\n" +
                "      \"collectionName\": \"The Best of 1980-1990\",\n" +
                "      \"trackName\": \"Angel of Harlem\",\n" +
                "      \"collectionCensoredName\": \"The Best of 1980-1990\",\n" +
                "      \"trackCensoredName\": \"Angel of Harlem\",\n" +
                "      \"artistViewUrl\": \"https://music.apple.com/us/artist/u2/78500?uo=4\",\n" +
                "      \"collectionViewUrl\": \"https://music.apple.com/us/album/angel-of-harlem/1440894594?i=1440894914&uo=4\",\n" +
                "      \"trackViewUrl\": \"https://music.apple.com/us/album/angel-of-harlem/1440894594?i=1440894914&uo=4\",\n" +
                "      \"previewUrl\": \"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview118/v4/d3/32/5e/d3325ef7-cfaa-814d-d552-6eb2d8c7d094/mzaf_5311251546349851412.plus.aac.p.m4a\",\n" +
                "      \"artworkUrl30\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/30x30bb.jpg\",\n" +
                "      \"artworkUrl60\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/60x60bb.jpg\",\n" +
                "      \"artworkUrl100\": \"https://is5-ssl.mzstatic.com/image/thumb/Music118/v4/69/9b/00/699b0088-acfd-5899-8f04-80e1192d107a/source/100x100bb.jpg\",\n" +
                "      \"collectionPrice\": 9.99,\n" +
                "      \"trackPrice\": 1.29,\n" +
                "      \"releaseDate\": \"1988-10-10T12:00:00Z\",\n" +
                "      \"collectionExplicitness\": \"notExplicit\",\n" +
                "      \"trackExplicitness\": \"notExplicit\",\n" +
                "      \"discCount\": 1,\n" +
                "      \"discNumber\": 1,\n" +
                "      \"trackCount\": 15,\n" +
                "      \"trackNumber\": 13,\n" +
                "      \"trackTimeMillis\": 229867,\n" +
                "      \"country\": \"USA\",\n" +
                "      \"currency\": \"USD\",\n" +
                "      \"primaryGenreName\": \"Rock\",\n" +
                "      \"isStreamable\": true\n" +
                "    }\n" +
                "  ]\n" +
                "}";
    }
}
