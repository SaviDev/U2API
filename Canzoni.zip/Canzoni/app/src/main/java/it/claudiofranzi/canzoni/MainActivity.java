package it.claudiofranzi.canzoni;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ListView lv_canzoni;
    ArrayList<Canzoni> canzoni;            // Model dati
    ArrayAdapter<Canzoni> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv_canzoni = findViewById(R.id.lv_canzoni);

        // carico il mio model
        try {
            canzoni = getJSON(canzoni);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        adapter = new ArrayAdapter<Canzoni>(getApplicationContext(), R.layout.row_custom, R.id.tv_collectionName, canzoni) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                TextView tv_collectionName = view.findViewById(R.id.tv_collectionName);
                tv_collectionName.setText(canzoni.get(position).getCollectionName());

                TextView tv_collectionPrice = view.findViewById(R.id.tv_collectionPrice);
                tv_collectionPrice.setText(Double.toString(canzoni.get(position).getCollectionPrice()));

                TextView tv_trackName = view.findViewById(R.id.tv_trackName);
                tv_trackName.setText(canzoni.get(position).getTrackName());

                TextView tv_trackPrice = view.findViewById(R.id.tv_trackPrice);
                tv_trackPrice.setText(Double.toString(canzoni.get(position).getTrackPrice()));

                return view;
            }
        };

        lv_canzoni.setAdapter(adapter);

        lv_canzoni.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // !!! aggiungere permessi di accesso alla rete nel file MANIFEST

                // dichiarare FUORI
                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(canzoni.get(i).getPreviewUrl());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();
            }
        });
    }

    public ArrayList<Canzoni> getJSON (ArrayList<Canzoni> canzoni) throws JSONException {
        canzoni = new ArrayList<Canzoni>();

        JSONObject canzoni_json = new JSONObject(Model.getJSON());
        JSONArray canzoni_array = canzoni_json.getJSONArray("results");
        for (int i=0; i<canzoni_array.length(); i++) {
            JSONObject canzone = canzoni_array.getJSONObject(i);
            String collectionName   = canzone.getString("collectionName");

            String trackName        = canzone.getString("trackName");
            String previewUrl       = canzone.getString("previewUrl");
            double collectionPrice  = canzone.getDouble("collectionPrice");
            double trackPrice       = canzone.getDouble("trackPrice");
            Canzoni canzone_json = new Canzoni(collectionName, trackName, previewUrl, collectionPrice, trackPrice);
            canzoni.add(canzone_json);
        }
        return canzoni;
    }
}